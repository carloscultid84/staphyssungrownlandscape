library(SoDA)
library(spdep)
library(ncf)
library(ade4)
library(gstat)
library(geoR)
library(sp)
library(Hmisc)
library(nlme)

library(MuMIn)
library(tidyverse)
library(caret)
library(MASS)
library(ggplot2)
library(lm.br)
library(corrplot)
install.packages("EnvStats")
library(EnvStats)

#####loading the data############

####Data variables (e.i., diversity estimations, abundance and predictors variables)

esc0 <- readRDS("data_All.rds")
names(esc0)

vx <- esc0[, c(5:19)] ####Scale Predictor Variables 
names(vx)


#######################Step 3#####################

####Spatial data, X and Y coordinates. The code of the sites following the same order that figure 1. n = 27 sampling site.

geo_data <- readRDS("geo_data.rds")

xy <- geo_data[,-1]
xy_coords <- as.matrix(xy) 

xy_centre <- scale(xy_coords, scale = F)
X <- xy_centre[,1]
Y <- xy_centre[,2]

XY <- cbind(X, Y)
plot(XY)

d1 <- esc0$Q1
hist(d1)
qqnorm(d1)
qqline(d1)
(shapiro.test(d1)) ###The 1D is normal and symetric, therefore is possible applied the protocol for identify and extract the spatial gradient pattern. W = 0.95347, p-value = 0.2599 (Negrete-Yankelevich & Fox 2015).

##To visualized better the spatial gradients patterns regarding the center coordinates (e.i., XY).

sd1 <- scale(d1, scale = F) ##1D scale.

###Bubble maps
par(mfrow=c(2,2), adj = 1)
s.value(XY, sd1) #### observed spatial pattern
s.value(XY, (X^2-X*Y-Y^2)) #### candited spatial pattern 1
s.value(XY, (X^2+3*X*3*Y-Y^2))### candited spatial pattern 2 posible
s.value(XY, (X^2+X*Y+Y^2)) ### candited spatial pattern 3

####Evaluation of the potential spatial gradients on 1D from candited pattern 2 (see Bublle maps).

d1d <- lm(d1 ~ I(X^2) + X*Y - I(Y^2)) 
summary(d1d)
extractAIC(d1d)
shapiro.test(residuals(d1d))
rd1d <- residuals(d1d)

d2d <- lm(d1 ~ I(X^2) + Y) 
summary(d2d)
extractAIC(d2d)
shapiro.test(residuals(d2d))
rd2d <- residuals(d2d) ###selected detrent 

d3d <- lm(d1 ~ Y) 
summary(d3d)
extractAIC(d3d)
shapiro.test(residuals(d3d))
rd3d <- residuals(d3d)

###Modelo sobre los residuales sin tendencia

mdt <- lm(rd2d ~ vx$CD+vx$DH+vx$Area_Caf�+vx$NP_BOS)
summary(mdt)
shapiro.test(residuals(mdt))
rmdt <- residuals(mdt)
plot(mdt)

###########################Modelling of the detrend response variable######################

##Regarding to p-value of the candidate spatial models, we selected the lm(d1 ~ I(X^2) + Y) fitted from lm(d1 ~ I(X^2) + X*Y - I(Y^2)).This approach extract the spatial gradient patters of the 1D. Therefore, we modeled the residuals of the candidate spatial models like response variable or 1D detrend.

###Step 2 (see analysis)
#########################Semivariograms##############################

ress <- rd2d  ##Here load the residual object for each model, rm-----.

rv_vxy <- data.frame(geo_data$X, geo_data$Y, ress)
g_vxy <- as.geodata(rv_vxy)
plot.geodata(g_vxy) ###exploring plot, min distance: ~1371 m; max distance: ~16037 m. Don't included in the paper. 

##Point variogram bulding with 2/3 of the max distance = aprox. 10700
varidist_rv <- variog(g_vxy, max.dist = 10700,
                      option = c("bin"),
                      breaks = seq(0, 10700, l = 11))

par (mfrow = c(1, 2))

vgm_cloud1 <- variog(g_vxy, option = "cloud", max.dist = 10700) ###Cloud variogram

plot(vgm_cloud1, main = "", xlab = "Distance (m)",
     ylab = "Semi-varianza")

(max(varidist_rv$v))
yplus = varidist_rv$v + 1.96 * sqrt (2) * varidist_rv$v / sqrt (varidist_rv$n); (max(yplus))
yminus = varidist_rv$v - 1.96 * sqrt (2) * varidist_rv$v / sqrt (varidist_rv$n)

plot(varidist_rv, xlab = "Distance (m)",
     ylab = "Semi-varianza", ylim = c(0,16)) #the range is define regarding the varidist_rv$v and yplus of the 95% IC (see below).

##########95% IC to semivariance plot. Run only after the last lines. 
errbar (varidist_rv$u, varidist_rv$v, yplus, yminus, add = T)

####################Theoretical Spatial Models (TSM)####################

# Total square sum to estimate the R2 in each TSM 
wtss1 <- sum (varidist_rv$n * (varidist_rv$v - weighted.mean(varidist_rv$v, varidist_rv$n))  ^ 2)

########Linear

lin1 <- variofit (varidist_rv, cov.model = "linear", weights = "npairs")
lin1

# Nugget
lin1$nugget

# C1
lin1$cov.pars [1]

# Sill 
lin1$cov.pars [1] + lin1$nugget

# Model line
lines (lin1, lwd = 2, lty = 1)

# R2 total explained variance for the TSM 

lin1.2<- 1 - lin1$value/wtss1
lin1.2

############################ Spherical 
sphp1 <- variofit(varidist_rv, cov.model = "sph", weights = "npairs")
sphp1

# Este modelo estima un rango de phi(4800.008) con un umbral (C + C0) de 
sphp1$nugget

sphp1$cov.pars [1]

sphp1$cov.pars [1] + sphp1$nugget 

lines (sphp1, lwd = 2, lty = 1)

sphwr1.2 <- 1 - sphp1$value / wtss1
sphwr1.2

############################ Exponential 

expp1 <- variofit (varidist_rv, cov.model = "exp", weights = "npairs")
expp1

expp1$nugget

expp1$cov.pars [1] 

expp1$cov.pars [1] + expp1$nugget

lines (expp1, lwd = 2, lty = 1)

expp1.2 <- 1 - expp1$value / wtss1
expp1.2

############################ Gaussian

gaup1 <- variofit (varidist_rv, cov.model = "gau", weights = "npairs")
gaup1

gaup1$nugget

gaup1$cov.pars [1]

gaup1$cov.pars [1] + gaup1$nugget

lines (gaup1, lwd = 2, lty = 2)

gau1.2<- 1 - gaup1$value / wtss1
gau1.2

#######################Step 4#####################

options(na.action = "na.fail")
colnames(vx)

vxx <- vx[,-8] ##Without DLT.

em1 <- lm(rd2d ~ .,vxx)  
e.mod1 <- dredge(em1, rank = "AICc")

s.e1 <- subset(e.mod1 , delta < 2)
#plot(s.e1$df, s.e1$delta)
model1 <- get.models(s.e1, subset=TRUE)

ma1 <- model.avg(e.mod1, subset = delta < 2) ###Average models
swt1 <- sw(ma1) ##
#sma1 <- summary(ma1)

###################The best models was the m1109

model1$`1109`
summary(model1$`1109`)
rmd1 <- residuals(model1$`1109`)
shapiro.test(rmd1)
AICc(model1$`1109`)

###Step 2 (see analysis)
#########################Semivariograms##############################

ress <- rmd1  ##Here load the residual object for each model, rm-----.

rv_vxy <- data.frame(geo_data$X, geo_data$Y, ress)
g_vxy <- as.geodata(rv_vxy)
plot.geodata(g_vxy) ###exploring plot, min distance: ~1371 m; max distance: ~16037 m. Don't included in the paper. 

##Point variogram bulding with 2/3 of the max distance = aprox. 10700
varidist_rv <- variog(g_vxy, max.dist = 10700,
                      option = c("bin"),
                      breaks = seq(0, 10700, l = 11))

par (mfrow = c(1, 2))

vgm_cloud1 <- variog(g_vxy, option = "cloud", max.dist = 10700) ###Cloud variogram

plot(vgm_cloud1, main = "", xlab = "Distance (m)",
     ylab = "Semi-varianza")

(max(varidist_rv$v))
yplus = varidist_rv$v + 1.96 * sqrt (2) * varidist_rv$v / sqrt (varidist_rv$n); (max(yplus))
yminus = varidist_rv$v - 1.96 * sqrt (2) * varidist_rv$v / sqrt (varidist_rv$n)

plot(varidist_rv, xlab = "Distance (m)",
     ylab = "Semi-varianza", ylim = c(0,9)) #the range is define regarding the varidist_rv$v and yplus of the 95% IC (see below).

##########95% IC to semivariance plot. Run only after the last lines. 
errbar (varidist_rv$u, varidist_rv$v, yplus, yminus, add = T)

####################Theoretical Spatial Models (TSM)####################

# Total square sum to estimate the R2 in each TSM 
wtss1 <- sum (varidist_rv$n * (varidist_rv$v - weighted.mean(varidist_rv$v, varidist_rv$n))  ^ 2)

########Linear

lin1 <- variofit (varidist_rv, cov.model = "linear", weights = "npairs")
lin1

# Nugget
lin1$nugget

# C1
lin1$cov.pars [1]

# Sill 
lin1$cov.pars [1] + lin1$nugget

# Model line
lines (lin1, lwd = 2, lty = 1)

# R2 total explained variance for the TSM 

lin1.2<- 1 - lin1$value/wtss1
lin1.2

############################ Spherical 
sphp1 <- variofit(varidist_rv, cov.model = "sph", weights = "npairs")
sphp1

# Este modelo estima un rango de phi(4800.008) con un umbral (C + C0) de 
sphp1$nugget

sphp1$cov.pars [1]

sphp1$cov.pars [1] + sphp1$nugget 

lines (sphp1, lwd = 2, lty = 1)

sphwr1.2 <- 1 - sphp1$value / wtss1
sphwr1.2

############################ Exponential 

expp1 <- variofit (varidist_rv, cov.model = "exp", weights = "npairs")
expp1

expp1$nugget

expp1$cov.pars [1] 

expp1$cov.pars [1] + expp1$nugget

lines (expp1, lwd = 2, lty = 1)

expp1.2 <- 1 - expp1$value / wtss1
expp1.2

############################ Gaussian

gaup1 <- variofit (varidist_rv, cov.model = "gau", weights = "npairs")
gaup1

gaup1$nugget

gaup1$cov.pars [1]

gaup1$cov.pars [1] + gaup1$nugget

lines (gaup1, lwd = 2, lty = 2)

gau1.2<- 1 - gaup1$value / wtss1
gau1.2


###end



