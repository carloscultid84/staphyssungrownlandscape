########Loading the packages###############

library(lme4)
require(blme)
library(bbmle)
library(MASS)         
library(nlme)
library(stats4)
library(Matrix)
library(Rcpp)

# Auxiliars
library(ggplot2) 
library(scales)  
library(lattice)
library(car)
library(gridExtra)
library(grid)
library(aods3)
library(boot)
library(glm2)
library(rsq)
library(geoR)
library(Hmisc)

#####loading the data############

####Data variables (e.i., diversity estimations, abundance and predictors variables)

esc0 <- readRDS("data_All.rds")
names(esc0)

vx <- esc0[, c(5:19)] ####Scale Predictor Variables 
names(vx)

####Spatial data, X and Y coordinates. The code of the sites following the same order that figure 1. n = 27 sampling site.
geo_data <- readRDS("geo_data.rds")

#########Selected models for each variables. See Table S1.###############

m1059 <- lm(esc0$Q0 ~ vx$DC+vx$Area_BOS+vx$NP_BOS) #0D
summary(m1059)
rm1059 <- residuals(m1059) 

m1109 <- lm(esc0$Q1 ~ vx$CD+vx$DH+vx$Area_Caf�+vx$NP_BOS) #1D
summary(m1109)
rm1109 <- residuals(m1109) 
shapiro.test(rm1109)

m81 <-lm(esc0$Q2 ~ vx$CD+vx$DH)#2D
summary(m81)
rm81 <- residuals(m81) 
shapiro.test(rm81)

m4100 <-  lm(log(esc0$Inds) ~ vx$AC+vx$PEND+vx$Area_BOS) #Ln(N)
summary(m4100)
rm4100 <- residuals(m4100) 
shapiro.test(rm4100)

#########################Semivariograms##############################

ress <- rm4100  ##Here load the residual object for each model, rm-----.

rv_vxy <- data.frame(geo_data$X, geo_data$Y, ress)
g_vxy <- as.geodata(rv_vxy)
plot.geodata(g_vxy) ###exploring plot, min distance: ~1371 m; max distance: ~16037 m. Don't included in the paper. 

##Point variogram bulding with 2/3 of the max distance = aprox. 10700
varidist_rv <- variog(g_vxy, max.dist = 10700,
                    option = c("bin"),
                    breaks = seq(0, 10700, l = 11))

par (mfrow = c(1, 2))

vgm_cloud1 <- variog(g_vxy, option = "cloud", max.dist = 10700) ###Cloud variogram

plot(vgm_cloud1, main = "", xlab = "Distance (m)",
      ylab = "Semi-varianza")

(max(varidist_rv$v))
yplus = varidist_rv$v + 1.96 * sqrt (2) * varidist_rv$v / sqrt (varidist_rv$n); (max(yplus))
yminus = varidist_rv$v - 1.96 * sqrt (2) * varidist_rv$v / sqrt (varidist_rv$n)

plot(varidist_rv, xlab = "Distance (m)",
      ylab = "Semi-varianza", ylim = c(0,0.4)) #the range is define regarding the varidist_rv$v and yplus of the 95% IC (see below).

##########95% IC to semivariance plot. Run only after the last lines. 
errbar (varidist_rv$u, varidist_rv$v, yplus, yminus, add = T)

####################Theoretical Spatial Models (TSM)####################

# Total square sum to estimate the R2 in each TSM 
wtss1 <- sum (varidist_rv$n * (varidist_rv$v - weighted.mean(varidist_rv$v, varidist_rv$n))  ^ 2)

########Linear

lin1 <- variofit (varidist_rv, cov.model = "linear", weights = "npairs")
lin1

# Nugget
lin1$nugget

# C1
lin1$cov.pars [1]

# Sill 
lin1$cov.pars [1] + lin1$nugget

# Model line
lines (lin1, lwd = 2, lty = 1)

# R2 total explained variance for the TSM 

lin1.2<- 1 - lin1$value/wtss1
lin1.2

############################ Spherical 
sphp1 <- variofit(varidist_rv, cov.model = "sph", weights = "npairs")
sphp1

# Este modelo estima un rango de phi(4800.008) con un umbral (C + C0) de 
sphp1$nugget

sphp1$cov.pars [1]

sphp1$cov.pars [1] + sphp1$nugget 

lines (sphp1, lwd = 2, lty = 1)

sphwr1.2 <- 1 - sphp1$value / wtss1
sphwr1.2

############################ Exponential 

expp1 <- variofit (varidist_rv, cov.model = "exp", weights = "npairs")
expp1

expp1$nugget

expp1$cov.pars [1] 

expp1$cov.pars [1] + expp1$nugget

lines (expp1, lwd = 2, lty = 1)

expp1.2 <- 1 - expp1$value / wtss1
expp1.2

############################ Gaussian

gaup1 <- variofit (varidist_rv, cov.model = "gau", weights = "npairs")
gaup1

gaup1$nugget

gaup1$cov.pars [1]

gaup1$cov.pars [1] + gaup1$nugget

lines (gaup1, lwd = 2, lty = 2)

gau1.2<- 1 - gaup1$value / wtss1
gau1.2
