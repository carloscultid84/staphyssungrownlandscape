library(MuMIn)
library(tidyverse)
library(caret)
library(MASS)
library(ggplot2)
library(PerformanceAnalytics)
library(lm.br)
library(corrplot)
library(Hmisc)
library(EnvStats)


###Scebario No. 0. Using Smith et al. 2009. Usar un proceso de selecci�n de variables seg�n la significancia. Da lo mismo que eliminar las variables por VIF.
esc0 <- readRDS("data_All.rds")
head(esc0)
names(esc0)
vx <- esc0[, c(5:19)] 
names(vx)

#########################Richnesss models###################################

options(na.action = "na.fail")
em0 <- lm(esc0$Q0 ~ .,vx)  
e.mod0 <- dredge(em0, rank = "AICc")

s.e0 <- subset(e.mod0 , delta < 2)
#plot(s.e1$df, s.e1$delta)
model0 <- get.models(s.e0, subset=TRUE)

ma0 <- model.avg(e.mod0, subset = delta < 2)
swt <- sw(ma0) ##aqu� se obtiene el peso de cada variable
#sma1 <- summary(ma1)

tsmodels <- ma0$msTable
tsmodels$Modeln <- modeln
tsmodels$Vx <- rownames(tsmodels)
rownames(tsmodels) <- seq(1:6) 
tsmodels$r2 <- r2
tsmodels$ps <- p_shap
tsmodels

#########################D1 (equally common species) ###################################
########################################################################################

options(na.action = "na.fail")
em1 <- lm(esc0$Q1 ~ .,vx)  
e.mod1 <- dredge(em1, rank = "AICc")

s.e1 <- subset(e.mod1 , delta < 2)
#plot(s.e1$df, s.e1$delta)
model1 <- get.models(s.e1, subset=TRUE)

ma1 <- model.avg(e.mod1, subset = delta < 2)
swt1 <- sw(ma1) ##aqu� se obtiene el peso de cada variable
#sma1 <- summary(ma1)

num(swt1)
tsmodels1 <- ma1$msTable
tsmodels1$Modeln <- modeln
tsmodels1$Vx <- rownames(tsmodels1)
rownames(tsmodels1) <- seq(1:4) 
tsmodels1$r2 <- r2
tsmodels1$ps <- p_shap
tsmodels1

#########################D2 (dominant species) ###################################
########################################################################################

options(na.action = "na.fail")
em2 <- lm(esc0$Q2 ~ .,vx)  
e.mod2 <- dredge(em2, rank = "AICc")

s.e2 <- subset(e.mod2 , delta < 2)
#plot(s.e1$df, s.e1$delta)
model2 <- get.models(s.e2, subset=TRUE)

ma2 <- model.avg(e.mod2, subset = delta < 2)
swt2 <- sw(ma2) ##aqu� se obtiene el peso de cada variable
#sma1 <- summary(ma1)

num(swt2)
tsmodels2 <- ma2$msTable
tsmodels2$Modeln <- modeln2
tsmodels2$Vx <- rownames(tsmodels2)
rownames(tsmodels2) <- seq(1:9) 
tsmodels2$r2 <- r22
tsmodels2$ps <- p_shap2
tsmodels2

#########################LnAbund (abundance) ###################################
########################################################################################

options(na.action = "na.fail")
em3 <- lm(log(esc0$Inds) ~ .,vx)  
e.mod3 <- dredge(em3, rank = "AICc")

s.e3 <- subset(e.mod3 , delta < 2)
#plot(s.e1$df, s.e1$delta)
model3 <- get.models(s.e3, subset=TRUE)

ma3 <- model.avg(e.mod3, subset = delta < 2)
swt3 <- sw(ma3) ##aqu� se obtiene el peso de cada variable
#sma1 <- summary(ma1)

num(swt3)

tsmodels3 <- ma3$msTable
tsmodels3$Modeln <- modeln3
tsmodels3$Vx <- rownames(tsmodels3)
rownames(tsmodels3) <- seq(1:11) 
tsmodels3$r2 <- r23
tsmodels3$ps <- p_shap3
tsmodels3