library(ggplot2)
library(pvclust)
library(fpc)
library(BAT)#para Carvalho et al. 2012
library(fpc)
library(adespatial)
library(vegan)

setwd("C:\\Users\\Dell\\Documents\\An�lisis R\\Staph_Doc\\beta")

#####Staphylinidae community data
tv <- read.table("staphy_4.txt", header = T)
a<-tv[,-1]
names(a)
b.tv=as.matrix((tv > 0) + 0)

#####General beta diversity bewteen traps
beta.multi(b.tv, abund = FALSE, func = "jaccard",  raref = 0, runs = 1000)

###beta total Caravlo with jaccard index bewteen traps
betaJ <- beta(b.tv, abund = FALSE, func = "jaccard", raref = 0, runs = 1000)
btotal <- betaJ$Btotal
brep <- betaJ$Brepl
brich <- betaJ$Brich

###environmental data
setwd("C:\\Users\\Dell\\Documents\\An�lisis R\\Staph_Doc\\beta")
vx <- read.csv("Data_trampa_new.csv", header = T, sep = ";")
names(vx)
amb <- vx[,-c(1:2)] ###crudas
names(amb)
sitios<-vx$Sitios


##First permanova with predictive variable both scale
stap.div<-adonis2(btotal ~ ., data= amb, permutations = 9999, method="jaccard")
print(stap.div)

##Second permanova using only the sampling sites as categoric variable
perma_categ<-adonis2(btotal~ sitios, permutations = 9999, method="jaccard")
perma_categ

##a permutational test for the homogeneity of group dispersion 
dispersion<-betadisper(btotal, group = sitios)
anova(dispersion)
permutest(dispersion, permutations = 9999)                             
plot(dispersion, hull=FALSE, ellipse=TRUE) ##sd ellipse
boxplot(dispersion)

